function C = euclidean_geodesic(C1,C2,t)

    C = (1-t)*C1 + t*C2;
    