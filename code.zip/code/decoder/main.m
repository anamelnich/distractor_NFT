computeModel('e14');

%topoplot([ones(32,1);5*ones(31,1)],cfg.chanlocs)