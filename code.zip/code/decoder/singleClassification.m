function posterior = singleClassification(decoder, eeg, labels, type, leftElectrodes, rightElectrodes) %singleClassification(decoder, epochs.data(:, :, test_index))
if ~mislocked
    mlock
end

%% Select electrodes based on epoch labels

% Initialize the array for selected electrodes
n_samples = size(eeg, 1);
n_electrodes = 6; % Number of electrodes per trial
if type == 0
    n_trials = size(eeg, 3);
    selectedEpochs = nan(n_samples, n_electrodes, n_trials);
    for i_trial = 1:n_trials
        label = labels(i_trial);
    
        % Select electrode indices based on the label
        if label == 1 || label == 0 % Distractor on right
            electrodeIndices = leftElectrodes;
        elseif label == 2 %|| label == 0 % Distractor on left or no distractor
            electrodeIndices = rightElectrodes;
        else
            error('Unknown label');
        end
    
        % Store the data in epochs.data
        selectedEpochs(:, :, i_trial) = eeg(:, electrodeIndices, i_trial);
    
    end
    labels(labels == 2) = 1;
elseif type == 1
    selectedEpochs = nan(n_samples, n_electrodes);

    % Select electrode indices based on the label
    if labels == 202 || labels == 100 || labels == 110 % Distractor on right
        electrodeIndices = leftElectrodes;
    elseif labels == 204 %|| label == 0 % Distractor on left or no distractor
        electrodeIndices = rightElectrodes;
    else
        error('Unknown label');
    end

    % Store the data in epochs.data
    selectedEpochs(:, :) = eeg(:, electrodeIndices);
end
eeg = selectedEpochs;

%% Spatial Filter
n_trials = size(eeg, 3);
sf_eeg = nan(size(eeg,1), size(decoder.spatialFilter,2), n_trials);
for i_trial = 1:n_trials
    sf_eeg(:,:,i_trial) = eeg(:,:,i_trial) * decoder.spatialFilter;
end

%% Temporal Information
if (decoder.resample.is_compute)
    resamp = sf_eeg(decoder.resample.time(1:decoder.resample.ratio:end), :, :);
    resamp = reshape(resamp, [size(resamp,1)*size(resamp,2) n_trials]);
end

%% Power Spectral Density
if (decoder.psd.is_compute)
    psd_epoch = sf_eeg(decoder.psd.time, :,:);
    [psd, decoder] = compute_psd(decoder.psd.type, psd_epoch, decoder);
    psd = reshape(psd, [size(psd,1)*size(psd,2) n_trials]);
end

%% Riemannien Geometry
if (decoder.riemann.is_compute)
    riemann_epoch = sf_eeg(decoder.riemann.time, :, :);
    cov_matrix = covariances(permute(cat(2, repmat(decoder.riemann.avrgSignals, [1 1 n_trials]), riemann_epoch), [2 1 3]), 'shcovft');
    riemann = Tangent_space(cov_matrix, decoder.riemann.avrgCov);
end

%% Concatenate all computed features
epoch = nan(decoder.numFeatures, n_trials);
if (decoder.resample.is_compute)
    epoch(decoder.resample.range,:) = resamp;
end
if (decoder.psd.is_compute)
    epoch(decoder.psd.range,:) = psd;
end
if (decoder.riemann.is_compute)
    epoch(decoder.riemann.range,:) = riemann;
end

if isequal(decoder.classify.reduction.type, 'pca')
    epoch = decoder.classify.applyPCA(epoch)';
end

%% Normailize Features
if (decoder.classify.is_normalize)
    epoch = decoder.classify.funNormalize(epoch);
end

if ismember(decoder.classify.reduction.type, {'lasso', 'r2'})
    epoch = epoch(decoder.classify.keepIdx, :);
end

%% Classification
posterior = decoder.classify.model(epoch');
